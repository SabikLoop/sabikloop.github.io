#include <stdio.h>

int main(){

	float var[5]; 

	printf("Input five float numbers: "); 

	for (int i =0 ; i< 5; ++i){
		scanf("%f",&var[i]);
	}

	printf("Five numbers are: \n");

	for (int i = 0; i < 5; ++i){
		printf("%f\n", var[i]);
	}



}
