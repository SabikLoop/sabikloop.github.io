#include <stdio.h>

int main()
{

	float fahr, celsius; 

	int lower = 0, upper = 300, step = 20; 


	for (fahr = lower; fahr <= upper; fahr += step){
		celsius = (5.0/9.0)*(fahr - 32);
		printf("%3f %6f\n", fahr, celsius);
	}

}


	
