#include <stdio.h>

int main(){

	int c,d, blanks;

	while ((c = getchar())!=EOF){
		if (c == '\t'){
			putchar('\\');
			putchar('t');
			d = 1;
			blanks = 0;
		}
		if (c == '\b'){
			putchar('\\');
			putchar('b');
			d = 1; 
			blanks = 0;
		}
		if (c == '\\'){
			putchar('\\');
			putchar('\\');
			d = 1;
			blanks = 0;
		}
		if (c == ' ') {
			if (blanks == 0) {
				blanks = 1;
				putchar(' ');
			}
		}
		else {
			putchar(c);
			blanks = 0;
		}
}
}

