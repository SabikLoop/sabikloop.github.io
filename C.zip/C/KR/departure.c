#include <stdio.h>

int main(){

	int a = 480, b = 583, c = 679, d = 767, e = 840, f = 945, g = 1140, h = 1305; 
	int hour, minutes; 
	
	printf("Enter a 24-hour (hour:minute) time: ");
		scanf("%d:%d",&hour, &minutes);

	int time_since_midnight = 60 * hour + minutes; 

	if (time_since_midnight > a && time_since_midnight < b)    
		printf("Closest departure time is 8:00 am, arriving at 10:16 am\n");
	if (time_since_midnight > b  && time_since_midnight < c) 
		printf("Closest departure time is 9:43 am, arriving at 11:52 am\n");
	if (time_since_midnight > c  && time_since_midnight < d) 
		printf("Closest departure time is 11:19 am, arriving at 1:31 pm\n");
	if (time_since_midnight > d  && time_since_midnight < e) 
		printf("Closest departure 12:47pm, arriving at 3:00 pm\n");
	if (time_since_midnight > e  && time_since_midnight < f) 
		printf("Closest departure 2:00 pm, arriving at 4:08 pm\n");
	if (time_since_midnight > f  && time_since_midnight < g) 
		printf("Closest departure 3:45 pm, arriving at 5:45 pm\n");
	if (time_since_midnight > g && time_since_midnight < h)
		printf("Closest departure 7:00 pm, arriving at 10:00pm\n");
	if (time_since_midnight > h)
		printf("Closest departure 9:45 pm, arriving at 11:45pm\n");
}
