#include <stdio.h>

int main(){

	int nl = 0, blanks = 0, tabs = 0;
	int c;
	
	printf("Enter characters below: "); 


	while ((c = getchar())!= EOF){
		if (c == '\n')
			++nl; 
		if (c == ' ')
			++blanks; 
		if (c == '\t')
			++tabs; 
	}

	printf("Number of lines, blanks, and tabs: %d %d %d\n", nl, blanks, tabs); 

}



