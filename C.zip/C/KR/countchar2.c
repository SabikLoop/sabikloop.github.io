#include <stdio.h>

int main()
{

	double nc; 

	for (nc = 0; (getchar()!=EOF); nc++)
		;

	printf("Number of characters inputted : %.0f\n", nc-1);
}

