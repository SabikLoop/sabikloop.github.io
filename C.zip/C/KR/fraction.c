#include <stdio.h>

int main() 
{
	int num_1, num_2, num_result;
	int denum_1, denum_2, denum_result;

	printf("Enter first fraction: ");
	scanf("%d/%d", &num_1, &denum_1);
	printf("Enter second fraction: ");
	scanf("%d/%d", &num_2, &denum_2);

	num_result = num_1 * denum_2 + num_2 * denum_1;
	denum_result = denum_1 * denum_2; 

	printf("Sum of two fractions is: %d/%d\n", num_result, denum_result); 

}
