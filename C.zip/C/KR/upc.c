#include <stdio.h>

int main()
{
	int a,b,c,d,e,f,g,h,i,j,k, sum1, sum2, total;

	printf("Enter the first 11 digits of a UPC: ");

	scanf("%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d", &a,&b,&c,&d,&e,&f,&g,&h,&i,&j,&k);

	sum1 = a + c + e + g + i + k;
	sum2 = b + d + f + h + j; 
	total = 3 * sum1 + sum2; 
	printf("Check digit: %d\n", (9 - ((total - 1) % 10)));

	return 0;
}

