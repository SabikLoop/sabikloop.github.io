#include <stdio.h>

int main(){

	float income; 

	printf("Input income: ");
	scanf("%f", &income);

	if (income < 750)
		printf("Income tax owed: %f\n", .01f * income);
	if (income > 750 && income < 2250)
		printf("Income tax owed: %f\n", 7.50 + .02f * income);
	if (income > 2250 && income < 3750)
		printf("Income tax owed: %f\n", 37.50 + .03f * income); 
	if (income > 3750 && income < 5250)
		printf("Income tax owed: %f\n", 82.50 + .04f * income);
	if (income >5250 && income <7000)
		printf("Income tax owed: %f\n", 142.50 + .05f * income);
	if (income > 7000)
		printf("Income tax owed: %f\n", 230.00 + .06f * income);

}


