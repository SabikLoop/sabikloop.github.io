#include <stdio.h>

int main(){

	int var1, var2, var3; 

	float var4, var5, var6; 


	printf("Value of ints without initalization: %d %d %d", var1, var2, var3); 

	printf("value of floats without intialization: %f %f %f", var4, var5, var6);

	return 0;

}
