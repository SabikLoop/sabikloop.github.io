#include <stdio.h>

int main(){

	int money = 0;

	printf("Input whole number money: ");
	scanf("%d", &money);


	printf("$20 bills: %d\n", money / 20);
	money -= 20 * (money / 20);
	
	printf("$10 bills: %d\n", money / 10);
	money -= 10 * (money /10);
	printf("$5 bills: %d\n", money / 5);
	money -= 5 * (money / 5);
	printf("$1 bills: %d\n", money / 1);
	money -= 1 * (money / 1);
}
