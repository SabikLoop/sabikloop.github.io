#include <stdio.h>

int main(){

	for (int i = 0; i < 15; i+=3){
		if (i % 2 == 0) {
			printf("*");
		}
		else if (i % 2 != 0)
			printf("odd");
	
	}
}
