#include <stdio.h>

int main() {

	int a,b,c,e,d;
	printf("Enter a number between 0 and 32767: ");
	scanf("%d",&a);

	b = a / 8;
	c = b / 8; 
	d = c / 8;
	e = d / 8;

	printf("In octal, your number is: %d%d%d%d%d\n",(e%8), (d%8), (c%8), (b%8), (a%8));

}


	
	
