#include <stdio.h>

int main()
{
	int item;

	float unit_price;

	int mm, dd, yyyy;


	printf("Enter item number: ");
	scanf("%d", &item);

	printf("Enter unit price: ");
	scanf("%f", &unit_price);

	printf("Enter purchase date (mm/dd/yyyy): ");
	scanf("%d/%d/%d", &mm, &dd, &yyyy);

	printf("Item\t\tUnit\t\tPurchase\n");
	printf("\t\tPrice\t\tDate\n");
	printf("%d\t\t$%9.2f\t%d/%d/%d\n", item, unit_price, mm, dd, yyyy);


}


