#include <stdio.h>

int main(){

	float fahr, cel;
	float lower = 0, upper = 300, step = 20; 
	

	for (fahr = lower; fahr < upper; fahr += step) {
		printf("%3f %3f\t\n",fahr, (5.0/9.0)*(fahr - 32.0)); 
	}
}


