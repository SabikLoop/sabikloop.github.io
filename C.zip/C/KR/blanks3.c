#include <stdio.h>

int main(){

	int c; 
	int blank = 0; 

	while ((c = getchar())!=EOF){
		if (c == ' '){
			if (blank == 0){
				blank = 1;
				putchar(c);
			}
		}
		else {
			blank = 0;
			putchar(c);	
		}
	}
}

