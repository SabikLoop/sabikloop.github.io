#include <stdio.h>

int main() 
{
	int num_1, num_2, num_result;
	int denum_1, denum_2, denum_result;

	printf("Enter two fractions separated by a plus sign: ");

	scanf("%d/%d+%d/%d", &num_1, &denum_1, &num_2, &denum_2);

	num_result = num_1 * denum_2 + num_2 * denum_1;
	denum_result = denum_1 * denum_2; 

	printf("Sum of two fractions is: %d/%d\n", num_result, denum_result); 

}
