#include <stdio.h>

int main(){

	long nc; 

	nc = 0; 

	int c; 

	while (getchar()!=EOF)
       		nc++;	
	printf("Number of characters inputted: %ld\n", nc-1);

}


