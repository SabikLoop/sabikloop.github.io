#include <stdio.h>

int main(){

	int nl = 0, blanks = 0, tabs = 0;
	int c;
	
	while ((c = getchar())!=EOF)
		if (c == '\n')
			++nl;
		if (c == '\t')
			++tabs;
		if (c == ' ')
			++blanks;
	printf("Number of Lines, Blanks, and Tabs: %d %d %d\n", nl, blanks, tabs);

}



