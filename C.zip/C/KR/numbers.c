#include <stdio.h>

int main()
{
	printf("%3d %.3d", 83.24, 1040);
}
