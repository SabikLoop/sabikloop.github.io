#include <stdio.h>

int main()
{
	float loan, interest_rate, monthly_payment; 
	printf("Enter loan amount: ");
	scanf("%f", &loan);
	printf("Enter interest_rate amount: ");
	scanf("%f", &interest_rate);
	printf("Enter monthly_payment amount: ");
	scanf("%f", &monthly_payment);

	float per_interest_rate = ((interest_rate / 100) / 12);

	loan +=(per_interest_rate * loan) - monthly_payment;
	printf("Balance after first month: %f\n", loan);
	loan +=(per_interest_rate * loan) - monthly_payment;
	printf("Balance after second month: %f\n", loan);
	loan +=(per_interest_rate * loan) - monthly_payment; 
	printf("Balance after third month: %f\n", loan); 
	return 0;

}

		
