#include <stdio.h>
#define IN 0
#define OUT 1

int main(){

	int state, c; 
	state = IN; 
	while ((c = getchar())!=EOF){
		if (c == ' ' || c == '\t' || c == '\n'){
			if (state == IN) {
				state = OUT; 
				putchar('\n'); 
			}
		}

		else
		{
			state = IN; 
			putchar(c);
		}

	}
}

