#include <stdio.h>

int main()
{
	int a1,a2,a3,a4,arow;
	int b1,b2,b3,b4,brow;
	int c1,c2,c3,c4,crow;
	int d1,d2,d3,d4,drow;

	int col1,col2,col3,col4;
	int diag1,diag2;

	printf("Enter numbers 1-16 in any order :");
	scanf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",&a1,&a2,&a3,&a4,&b1,&b2,&b3,&b4,&c1,&c2,&c3,&c4,&d1,&d2,&d3,&d4);


	arow = a1 + a2 + a3 + a4;
	brow = b1 + b2 + b3 + b4;
	crow = c1 + c2 + c3 + c4;
	drow = d1 + d2 + d3 + d4;

	col1 = a1 + b1 + c1 + d1; 
	col2 = a2 + b2 + c2 + d2;
	col3 = a3 + b3 + c3 + d3;
	col4 = a4 + b4 + c4 + d4;

	diag1 = a1 + b2 + c3 + d4;
	diag2 = a4 + b3 + c2 + d1;
	
	printf("%d %d %d %d\n", a1,a2,a3,a4);
	printf("%d %d %d %d\n", b1,b2,b3,b4);
	printf("%d %d %d %d\n", c1,c2,c3,c4);
	printf("%d %d %d %d\n", d1,d2,d3,d4);

	printf("Row sums : %d %d %d %d\n", arow, brow, crow, drow);
	printf("Column sums: %d %d %d %d\n", col1, col2, col3, col4);
	printf("Diagonal sums: %d %d\n", diag1, diag2);

}

