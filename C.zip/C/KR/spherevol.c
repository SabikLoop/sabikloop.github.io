#include <stdio.h>

#define DIVISOR (4.0f / 3.0f)
#define PI 3.1415

int main(){
	int volume; 
	float radius;
	printf("Enter radius: ");
	scanf("%f", &radius);

	volume = DIVISOR * PI * (radius * radius * radius);
	
	printf("Volume of a sphere is: %d\n", volume);
	return 0;

}

