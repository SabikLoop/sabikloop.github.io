#include <stdio.h>

int main()
{
	int digits; 
	printf("Input a number between 0 and 9999: "); 
	scanf("%d", &digits);

	if (digits > 0 && digits < 10)
		printf("The number %d has 1 digits\n", digits);
	if (digits >= 10 && digits < 100)
		printf("The number %d has 2 digits\n", digits);
	if (digits >= 100 && digits < 1000)
		printf("The number %d has 3 digits\n", digits);
	if (digits >= 1000 && digits < 10000)
		printf("The number %d has 4 digits\n", digits);

}

		
