#include <stdio.h>

int main(){

	float celsius; 

	float lower = -40, upper = 100, step = 20;
	
	celsius = lower; 
	
	printf("Celsius  \tFahrenheit\n");
	

	while (celsius <= upper){
		
		float fahr = 32.0 + (9.0 * celsius) / 5.0; 
		
		printf("%3f\t %6f\n", celsius, fahr); 

		celsius += step; 

}
}

