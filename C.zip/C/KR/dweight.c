#include <stdio.h>

int main(){

	int length, width, height;

	printf("Input length: ");
	scanf("%d", &length);
	printf("input width: ");
	scanf("%d", &width);
	printf("input height: ");
	scanf("%d", &height);

	int volume = length * width * height; 

	printf("Weight is: %d\n", (volume+165) / 166); 

	return 0;

}
