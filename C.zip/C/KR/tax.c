#include <stdio.h>
#define TAX .05


int main(){

	float dollar;
	float taxamount;

	printf("Enter dollars-and-cents amount: ");
	scanf("%f", &dollar); 
	
	taxamount = dollar + (dollar * TAX);

	printf("Amount with tax included: $ %f\n", taxamount);

}
