#include <stdio.h>

int main(){
	
	int c, d;

	while ((c = getchar())!=EOF)
		putchar(c);

	if ((d = getchar())==EOF)
		printf("%d\n", d);
}

