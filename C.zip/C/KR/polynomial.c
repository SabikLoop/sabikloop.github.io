#include <stdio.h>

int main(){

	float x; 

	float function;

	printf("Enter a value for x: ");
	scanf("%f", &x);
	
	function = ((((3*x + 2)* x - 5)* x -1)* x + 7)* x-6;

	printf("The return value for the polynomial is: %.2f\n", function);

	return 0;

}
