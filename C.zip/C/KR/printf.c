#include <stdio.h>
int main()
{
	float x = 44.023234293;

	printf("%-8e.1", x);
	printf("%10e.f", x);
	printf("%-8.3f", x);
	printf("%6f", x);
}

