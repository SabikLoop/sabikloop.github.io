#include <stdio.h>

int main(){

	int digits;

	printf("Enter a three digit number: ");

	scanf("%d", &digits);
	
	printf("The reversal is: %d%d%d\n", (digits  % 10), ((digits / 10) % 10), ((digits/100)%10));

}


