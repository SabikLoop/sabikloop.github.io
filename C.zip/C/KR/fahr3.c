#include <stdio.h>

int main(){

	int fahr; 
	float celsius; 

	int upper = 300; 
	int step = 20;

	fahr = 0; 
	printf("Fahrenheit Celsius\t");
	while (fahr < upper){
		celsius = (5.0/9.0)*(fahr - 32); 
		printf("%d\t %f\n", fahr, celsius); 
		fahr += step;
	}

}


