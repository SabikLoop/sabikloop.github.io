#include <stdio.h>
#define FREEZING 32.0f 
#define SCALE (5.0f/9.0f)

int main(){

	float fahrenheit, celsius; 

	printf("Enter a fahrenheit temperature: ");

	scanf("%f\n", &fahrenheit);

	celsius = (fahrenheit - FREEZING) * SCALE;

	printf("Celsius is: %f\n", celsius);

	return 0;

}
