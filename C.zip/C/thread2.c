#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void *CustomThreadFunction(){


	for (int i =0; i < 5; i++){
		printf("I am a custom thread function created by programmer. \n");
		sleep(1);
		if (i ==3){
			printf("My job is completed. Exiting now...\n");
			pthread_exit(NULL);
		}
	}
	return NULL;
}
int main(){

	pthread_t thread; 
	pthread_create(&thread, NULL, CustomThreadFunction, NULL); 
	for (int i=0; i < 5; ++i){
		printf("I am process thread created by compiler by default. \n");
		sleep(1);
	}

	return 0;


}
