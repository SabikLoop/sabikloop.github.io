#include <stdio.h>

int main(){

	float var[5]; 

	int sum; 

	printf("Input five float numbers: "); 

	for (int i =0 ; i< 5; ++i){
		scanf("%f",&var[i]);
		sum += var[i];
	}

	printf("Five numbers are: \n");

	for (int i = 0; i < 5; ++i){
		printf("%f\n", var[i]);
	}

	printf("Sum is: %d\n", sum);

	int average = sum / 5; 
	
	printf("Average of numbers is: %d\n", average); 
	return 0;



}
