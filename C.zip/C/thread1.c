#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void *CustomThreadFunction(){


	for (int i =0; i < 15; i++){
		printf("I am a custom thread function created by programmer. \n");
		sleep(1);
	}
	return 0;
}
int main(){

	CustomThreadFunction();

}
